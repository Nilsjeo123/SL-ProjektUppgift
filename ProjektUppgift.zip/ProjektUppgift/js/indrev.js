/*
    niot5439
    raah3489
    nama3213
*/

$(document).ready(function() {

    var imageSRCs = [
        "../css/src/indRevPuzzel/1.png",
        "../css/src/indRevPuzzel/2.png",
        "../css/src/indRevPuzzel/3.png",
        "../css/src/indRevPuzzel/4.png",
        "../css/src/indRevPuzzel/5.png",
        "../css/src/indRevPuzzel/6.png",
        "../css/src/indRevPuzzel/7.png",
        "../css/src/indRevPuzzel/8.png",
        "../css/src/indRevPuzzel/9.png"
    ];

    var Questions=[  
        "Var kom de första förändringarna som på sikt ledde till industriella revolutionen?",
        "Vad kallas de små åkerremsorna man hade innan det stora skifter?",
        "Vilken av dessa saker gjorde man INTE för att förbättra jordbruket?",
        "Vad är Spinning Jenny?",
        "Vilket av dessa alternativ var INTE en förklaring till att ind. revolutionen började i Storbritanien?",
        "Vilket påstående är fel?",
        "Under 1700-talet spreds många sjukdomar, en av dem ledde till att man kom på vaccin - vilken sjukdom var det?",
        "Det fanns gott om detta i storbritanien och man kom på hur man kunde använda det som bränsle i ångmaskiner...?",
        "Ångmaskiner kom att förändra hela samhället och användes till väldigt mycket, men inte till att...?"];

    var Options=[
        ["Inom jordbruket", "Inom fisket", "Inom skogsbruket", "Inom gruvdrift"],
        ["Tegar", "Tänger", "Odlingsbäddar", "Allmänningar"],
        ["Började använda konstgödsel", "Avlade djur", "Införde växelbruk", "Skapade plogar"],
        ["En spinnmaskin", "En populär dans", "Ett vattenhjul", "En Jordbruksmaskin"],
        ["Många dog i krig", "Det fanns gott om ull", "Det fanns gott om hö", "Många var rika"],    
        ["Alla barn fick gå i skola", "Många dog innan 5 år", "Många barn arbetade i gruvor", "Barn fick lägre lön"],
        ["Smittkoppor", "Mässling", "Påssjuka", "Gulsot"],
        ["Stenkol", "Järnmalm", "Magnesium", "Träkol"],
        ["Flygplan", "Båtar", "Tåg", "Symaskiner"]
    ]; 

    var questionH1  = $("#fragorTitle"),
        button1     = $("#button1"),
        button2     = $("#button2"),
        button3     = $("#button3"),
        button4     = $("#button4"),
        canvasCTX   = $("#quizzCanvas")[0].getContext('2d'),
        nextButton  = $("#next"),
        feedback    = $("#svar");

    var question = Questions[0], correctAnswers = 0,
        answer1, answer2, answer3, answer4, correctAnswer;


    nextButton.hide();
    canvasCTX.canvas.width  = window.innerWidth;
    canvasCTX.canvas.height = window.innerHeight;
    fillText();

    /* Lägger in funktioner som kollar om den canvas som trycktes på hade rätt svar samt berättar det för användaren */
    button1.click(function() {
        submitAnswer(button1);
    })
    button2.click(function() {
        submitAnswer(button2);
    })
    button3.click(function() {
        submitAnswer(button3);
    })
    button4.click(function() {
        submitAnswer(button4);
    })
    

    function fillText(){
        correctAnswer = Options[Questions.indexOf(question)][0];
        var shuffledQuestions = Options[Questions.indexOf(question)].sort((a, b) => 0.5 - Math.random())
        answer1 = shuffledQuestions[0],
        answer2 = shuffledQuestions[1],
        answer3 = shuffledQuestions[2],
        answer4 = shuffledQuestions[3];
        questionH1.text(question)
        button1.text(answer1);
        button2.text(answer2);
        button3.text(answer3);
        button4.text(answer4);

        questionH1.show();
        button1.show();
        button2.show();
        button3.show();
        button4.show();
    }

    nextButton.click(function(){
        if(Questions.indexOf(question) == 8){
            alert("Slut på frågor!\nFick du inte alla puzzelbitar får du försöka igen!")
            return;
        }

        feedback.slideUp(500);
        nextButton.fadeOut(500);
        question = Questions[Questions.indexOf(question)+1];


        button1.css("background-color", "rgb(240, 140, 140)");
        button2.css("background-color", "rgb(240, 140, 140)");
        button3.css("background-color", "rgb(240, 140, 140)");
        button4.css("background-color", "rgb(240, 140, 140)");

        button1.prop('disabled', false);
        button2.prop('disabled', false);
        button3.prop('disabled', false);
        button4.prop('disabled', false);

        fillText();
    })

    function submitAnswer(button) {
        feedback.slideUp(500);
        nextButton.fadeIn(50);

        $("#quizzCanvas").show();
        
        button1.prop('disabled', true);
        button2.prop('disabled', true);
        button3.prop('disabled', true);
        button4.prop('disabled', true);
        
        if (button.text() == correctAnswer) {
            feedback.html("Rätt svar!");
            feedback.css("color", "green");
            button.css("background-color", "green");
            correctAnswers++;
            
            imageSRCs.forEach(src =>{
                if(imageSRCs.indexOf(src) < correctAnswers){
                    const image = new Image();
                    image.src = src;
                    image.onload = () => {
                        canvasCTX.drawImage(image, 5, window.innerHeight/2-5, window.innerWidth/3, window.innerHeight/2);
                    }
                }
            })
        }
        else {
            feedback.html("Du hade fel :(<br>Det korrekta svaret var:<br> " + correctAnswer);
            feedback.css("color", "red");
            button.css("background-color", "red");
        }


        localStorage.setItem("indrevBitar", correctAnswers);
        var str = feedback.html();
        feedback.html(str + "<br>Du har nu tjänat:<br>" + correctAnswers + " pussel bitar!");
        feedback.slideDown(1000);
    }

})