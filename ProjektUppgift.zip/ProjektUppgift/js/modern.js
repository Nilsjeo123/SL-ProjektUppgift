/*
    niot5439
    raah3489
    nama3213
*/

$(document).ready(function() {

    var imageSRCs = [
        "../css/src/modernPuzzel/1.png",
        "../css/src/modernPuzzel/2.png",
        "../css/src/modernPuzzel/3.png",
        "../css/src/modernPuzzel/4.png",
        "../css/src/modernPuzzel/5.png",
        "../css/src/modernPuzzel/6.png",
        "../css/src/modernPuzzel/7.png",
        "../css/src/modernPuzzel/8.png",
        "../css/src/modernPuzzel/9.png"
    ];

    var Questions=[  
        "Modern tid pågår fortfarande, men när startade den?",
        "Vilken dryck har gett namn åt händelsen i Boston som anses ha varit den utlösande faktorn för den amerikanska revolutionen?",
        "I vilket land dog Karl XII år 1718?",
        "Vem var Sveriges första statsminister 1876-1880?",
        "Lenin var ett revolutionärt täcknamn, vilket var Vladimir Lenins egentliga efternamn?",
        "Vilket krig pågick från 1950 till 1953?",
        "Berlinmuren byggdes 1961 men när föll den?",
        "Vilken svensk pop-grupp som skapades 1972 har gjort låtar som Waterloo och Mamma Mia?",
        "Omkring 1,1 miljoner, övervägande judar, dog i förintelselägret Auschwitz åren 1940–45. Var ligger Auschwitz?"];

    var Options=[
        ["Runt 1500", "Runt 1900", "Runt 2000", "Runt 1700"],
        ["Te", "Kaffe", "Saft", "Cider"],
        ["Norge", "Tyskland", "Sverige", "Polen"],
        ["Louis De Geer", "Arvid Posse", "Carl Johan Thyselius", "Stefan Löfven"],
        ["Uljanov", "Nikolajev", "Koroljov", "Ovechkin"],    
        ["Koreakriget", "Vietnamkriget", "Kalla kriget", "Andra världskriget"],
        ["1989", "1996", "2002", "2012"],
        ["Abba", "Roxette", "Ace of Base", "Avicii"],
        ["Polen", "Tyskland", "Österrike", "Schweiz"]
    ]; 


    var questionH1  = $("#fragorTitle"),
        button1     = $("#button1"),
        button2     = $("#button2"),
        button3     = $("#button3"),
        button4     = $("#button4"),
        canvasCTX   = $("#quizzCanvas")[0].getContext('2d'),
        nextButton  = $("#next"),
        feedback    = $("#svar");

    var question = Questions[0], correctAnswers = 0,
        answer1, answer2, answer3, answer4, correctAnswer;

    nextButton.hide();
    canvasCTX.canvas.width  = window.innerWidth;
    canvasCTX.canvas.height = window.innerHeight;
    fillText();

    /* Lägger in funktioner som kollar om den canvas som trycktes på hade rätt svar samt berättar det för användaren */
    button1.click(function() {
        submitAnswer(button1);
    })
    button2.click(function() {
        submitAnswer(button2);
    })
    button3.click(function() {
        submitAnswer(button3);
    })
    button4.click(function() {
        submitAnswer(button4);
    })
    

    function fillText(){
        correctAnswer = Options[Questions.indexOf(question)][0];
        var shuffledQuestions = Options[Questions.indexOf(question)].sort((a, b) => 0.5 - Math.random())
        answer1 = shuffledQuestions[0],
        answer2 = shuffledQuestions[1],
        answer3 = shuffledQuestions[2],
        answer4 = shuffledQuestions[3];
        questionH1.text(question)
        button1.text(answer1);
        button2.text(answer2);
        button3.text(answer3);
        button4.text(answer4);

        questionH1.show();
        button1.show();
        button2.show();
        button3.show();
        button4.show();
    }

    nextButton.click(function(){
        
        if(Questions.indexOf(question) == 8){
            alert("Slut på frågor!\nFick du inte alla puzzelbitar får du försöka igen!")
            return;
        }
        feedback.slideUp(500);
        nextButton.fadeOut(500);
        question = Questions[Questions.indexOf(question)+1];


        button1.css("background-color", "rgb(107, 204, 104)");
        button2.css("background-color", "rgb(107, 204, 104)");
        button3.css("background-color", "rgb(107, 204, 104)");
        button4.css("background-color", "rgb(107, 204, 104)");


        button1.prop('disabled', false);
        button2.prop('disabled', false);
        button3.prop('disabled', false);
        button4.prop('disabled', false);

        fillText();
    })

    function submitAnswer(button) {
        feedback.slideUp(500);
        nextButton.fadeIn(50);
        

        $("#quizzCanvas").show();

        button1.prop('disabled', true);
        button2.prop('disabled', true);
        button3.prop('disabled', true);
        button4.prop('disabled', true);

        
        if (button.text() == correctAnswer) {
            feedback.html("Rätt svar!");
            feedback.css("color", "green");
            button.css("background-color", "green");
            correctAnswers++;
            
            imageSRCs.forEach(src =>{
                if(imageSRCs.indexOf(src) < correctAnswers){
                    const image = new Image();
                    image.src = src;
                    image.onload = () => {
                        canvasCTX.drawImage(image, 5, window.innerHeight/2-5, window.innerWidth/2.5, window.innerHeight/2);  
                    }
                }
            })
        }
        else {
            feedback.html("Du hade fel :(<br>Det korrekta svaret var:<br> " + correctAnswer);
            feedback.css("color", "red");
            button.css("background-color", "red");
        }


        localStorage.setItem("modernBitar", correctAnswers);
        var str = feedback.html();
        feedback.html(str + "<br>Du har nu tjänat:<br>" + correctAnswers + " pussel bitar!");
        feedback.slideDown(1000);
    }

})