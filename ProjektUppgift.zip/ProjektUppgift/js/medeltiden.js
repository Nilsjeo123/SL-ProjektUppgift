/*
    niot5439
    raah3489
    nama3213
*/
$(document).ready(function() {

    var imageSRCs = [
        "../css/src/medelPuzzel/1.png",
        "../css/src/medelPuzzel/2.png",
        "../css/src/medelPuzzel/3.png",
        "../css/src/medelPuzzel/4.png",
        "../css/src/medelPuzzel/5.png",
        "../css/src/medelPuzzel/6.png",
        "../css/src/medelPuzzel/7.png",
        "../css/src/medelPuzzel/8.png",
        "../css/src/medelPuzzel/9.png"
    ];

    var Questions=[  
        "Ungefär hur stor del av befolkningen bodde på landsbygden?",
        "Vilken pest kom till sverige på 1300-talet?",
        "Vad hette kvinnan som helgonförklarades på 1300-talet och senare blev Europas skyddshelgon?",
        "Under vilket århundrade kom de första lagarna som började gälla för hela sverige?",
        "Vilka spår från medeltiden kan vi se i vår tid?",
        "Vem anser man grundade stockholm?",
        "Ett språk påverkade svenskan starkt under medeltiden, vilket?",
        "Vad hette den danske härskaren som ställde till med stockholms blodsbad?",
        "Tyckte kristendomen att man kunde vara gift med fler fruar under medeltiden?"];

    var Options=[
        ["95%", "75%", "85%", "45%"],
        ["Digerdöden", "Corona", "Spanska sjukan", "Råttdöden"],
        ["Birgitta", "Helena", "Astrid", "Karin"],
        ["1300", "1400", "1500", "1200"],
        ["Kyrkor och kloster", "Bilar", "Skansen", "Datorer"],    
        ["Birger Jarl", "Gustav Vasa", "Magnus Ladulås", "Sven"],
        ["Tyska", "Franska", "Engelska", "Hebreiska"],
        ["Kristan II", "Kristian III", "Mads Mikkelsen","Peder den korte"],
        ["Nej", "Ja", "Ja, om man var rik", "Bara Kungen fick ha fler fruar"]
    ]; 


    var questionH1  = $("#fragorTitle"),
        button1     = $("#button1"),
        button2     = $("#button2"),
        button3     = $("#button3"),
        button4     = $("#button4"),
        canvasCTX   = $("#quizzCanvas")[0].getContext('2d'),
        nextButton  = $("#next"),
        feedback    = $("#svar");

    var question = Questions[0], correctAnswers = 0,
        answer1, answer2, answer3, answer4, correctAnswer;
    
    
    nextButton.hide();
    canvasCTX.canvas.width  = window.innerWidth;
    canvasCTX.canvas.height = window.innerHeight;
    fillText();

    /* Lägger in funktioner som kollar om den canvas som trycktes på hade rätt svar samt berättar det för användaren */
    button1.click(function() {
        submitAnswer(button1);
    })
    button2.click(function() {
        submitAnswer(button2);
    })
    button3.click(function() {
        submitAnswer(button3);
    })
    button4.click(function() {
        submitAnswer(button4);
    })
    

    function fillText(){
        correctAnswer = Options[Questions.indexOf(question)][0];
        var shuffledQuestions = Options[Questions.indexOf(question)].sort((a, b) => 0.5 - Math.random())
        answer1 = shuffledQuestions[0],
        answer2 = shuffledQuestions[1],
        answer3 = shuffledQuestions[2],
        answer4 = shuffledQuestions[3];
        questionH1.text(question)
        button1.text(answer1);
        button2.text(answer2);
        button3.text(answer3);
        button4.text(answer4);

        questionH1.show();
        button1.show();
        button2.show();
        button3.show();
        button4.show();
    }

    nextButton.click(function(){
        if(Questions.indexOf(question) == 8){
            alert("Slut på frågor!\nFick du inte alla puzzelbitar får du försöka igen!")
            return;
        }
        feedback.slideUp(500);
        nextButton.fadeOut(500);
        question = Questions[Questions.indexOf(question)+1];


        button1.css("background-color", "rgb(226, 166, 117)");
        button2.css("background-color", "rgb(226, 166, 117)");
        button3.css("background-color", "rgb(226, 166, 117)");
        button4.css("background-color", "rgb(226, 166, 117)");


        button1.prop('disabled', false);
        button2.prop('disabled', false);
        button3.prop('disabled', false);
        button4.prop('disabled', false);

        fillText();
    })

    function submitAnswer(button) {
        feedback.slideUp(500);
        nextButton.fadeIn(50);

        $("#quizzCanvas").show();

        button1.prop('disabled', true);
        button2.prop('disabled', true);
        button3.prop('disabled', true);
        button4.prop('disabled', true);

        
        if (button.text() == correctAnswer) {
            feedback.html("Rätt svar!");
            feedback.css("color", "green");
            button.css("background-color", "green");
            correctAnswers++;
            
            imageSRCs.forEach(src =>{
                if(imageSRCs.indexOf(src) < correctAnswers){
                    const image = new Image();
                    image.src = src;
                    image.onload = () => {
                        canvasCTX.drawImage(image, 5, window.innerHeight/2-5, window.innerWidth/3, window.innerHeight/2);  
                    }
                }
            })
        }
        else {
            feedback.html("Du hade fel :(<br>Det korrekta svaret var:<br> " + correctAnswer);
            feedback.css("color", "red");
            button.css("background-color", "red");
        }

        localStorage.setItem("medelBitar", correctAnswers);
        var str = feedback.html();
        feedback.html(str + "<br>Du har nu tjänat:<br>" + correctAnswers + " pussel bitar!");
        feedback.slideDown(1000);
    }

})