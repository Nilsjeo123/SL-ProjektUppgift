/*
    niot5439
    raah3489
    nama3213
*/

$(document).ready(function() {

    var imageSRCs = [
        "../css/src/vikingPuzzel/1.png",
        "../css/src/vikingPuzzel/2.png",
        "../css/src/vikingPuzzel/3.png",
        "../css/src/vikingPuzzel/4.png",
        "../css/src/vikingPuzzel/5.png",
        "../css/src/vikingPuzzel/6.png",
        "../css/src/vikingPuzzel/7.png",
        "../css/src/vikingPuzzel/8.png",
        "../css/src/vikingPuzzel/9.png"
    ];

    var Questions=[  
        "När började vikingatiden?",
        "Vad kallade vikingarna det som idag är Nordamerika?",
        "En träl är ungefär samma sak som en?",
        "De flesta människorna på vikingatiden var?",
        "Hur kunde vikingarna dokumentera det som skedde på vikingatiden?",
        "Vad hette vikingen som upptäckte nordamerika?",
        "Vart hamnade riktigt tappra krigare när de dog, enligt nordisk mytologi?",
        "Vad tror man att ordet viking betyder?",
        "Vem av dessa personer var en känd viking?"];

    var Options=[
        ["ca år 800","ca år 900","ca år 700", "ca år 1000"],
        ["Vinland","Öland","Saftland", "Strandby"],
        ["Slav","Kung","Gud", "Drottning"],
        ["Bönder", "Krigare", "Lata", "Bagare"],
        ["Rista i runor", "Skrev i böcker", "Målade i grottor", "Vloggade"],    
        ["Leif Eriksson", "Torsten Skägg", "Hans den gröne", "Balder Byxa"],
        ["Valhall", "Midgård", "Hel", "Disneyland"],
        ["Från viken", "Skäggig krigare", "Handelsresande", "Skogstroll"],
        ["Harald Blåtand", "Halfdan Gultunga", "Hans Blodöga", "Sten Styre"]
    ]; 

    var questionH1  = $("#fragorTitle"),
        button1     = $("#button1"),
        button2     = $("#button2"),
        button3     = $("#button3"),
        button4     = $("#button4"),
        canvasCTX   = $("#quizzCanvas")[0].getContext('2d'),
        nextButton  = $("#next"),
        feedback    = $("#svar");

    var question = Questions[0], correctAnswers = 0,
        answer1, answer2, answer3, answer4, correctAnswer;

    nextButton.hide();
    canvasCTX.canvas.width  = window.innerWidth;
    canvasCTX.canvas.height = window.innerHeight;
    fillText();

    /* Lägger in funktioner som kollar om den canvas som trycktes på hade rätt svar samt berättar det för användaren */
    button1.click(function() {
        submitAnswer(button1);
    })
    button2.click(function() {
        submitAnswer(button2);
    })
    button3.click(function() {
        submitAnswer(button3);
    })
    button4.click(function() {
        submitAnswer(button4);
    })
    

    function fillText(){
        correctAnswer = Options[Questions.indexOf(question)][0];
        var shuffledQuestions = Options[Questions.indexOf(question)].sort((a, b) => 0.5 - Math.random())
        answer1 = shuffledQuestions[0],
        answer2 = shuffledQuestions[1],
        answer3 = shuffledQuestions[2],
        answer4 = shuffledQuestions[3];
        questionH1.text(question)
        button1.text(answer1);
        button2.text(answer2);
        button3.text(answer3);
        button4.text(answer4);

        questionH1.show();
        button1.show();
        button2.show();
        button3.show();
        button4.show();
    }

    nextButton.click(function(){


        if(Questions.indexOf(question) == 8){
            alert("Slut på frågor!\nFick du inte alla puzzelbitar får du försöka igen!")
            return;
        }
        feedback.slideUp(500);
        nextButton.fadeOut(500);
        question = Questions[Questions.indexOf(question)+1];


        button1.css("background-color", "rgb(104, 184, 204)");
        button2.css("background-color", "rgb(104, 184, 204)");
        button3.css("background-color", "rgb(104, 184, 204)");
        button4.css("background-color", "rgb(104, 184, 204)");

        button1.prop('disabled', false);
        button2.prop('disabled', false);
        button3.prop('disabled', false);
        button4.prop('disabled', false);

        fillText();
    })

    function submitAnswer(button) {
        feedback.slideUp(500);
        nextButton.fadeIn(50);

        $("#quizzCanvas").show();


        button1.prop('disabled', true);
        button2.prop('disabled', true);
        button3.prop('disabled', true);
        button4.prop('disabled', true);

        
        if (button.text() == correctAnswer) {
            feedback.html("Rätt svar!");
            feedback.css("color", "green");
            button.css("background-color", "green");
            correctAnswers++;
            imageSRCs.forEach(src =>{
                if(imageSRCs.indexOf(src) < correctAnswers){
                    const image = new Image();
                    image.src = src;
                    image.onload = () => {
                        canvasCTX.drawImage(image, 5, window.innerHeight/3);
                    }
                }
            })
        }
        else {
            feedback.html("Du hade fel :(<br>Det korrekta svaret var:<br> " + correctAnswer);
            feedback.css("color", "red");
            button.css("background-color", "red");
        }

        localStorage.setItem("vikingBitar", correctAnswers);
        var str = feedback.html();
        feedback.html(str + "<br>Du har nu tjänat:<br>" + correctAnswers + " pussel bitar!");
        feedback.slideDown(1000);
    }

})