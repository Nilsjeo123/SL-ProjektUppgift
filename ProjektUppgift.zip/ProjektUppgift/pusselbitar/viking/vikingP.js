/*
    niot5439
    raah3489
    nama3213
*/

$(document).ready(function() {

    //Bild källa: https://skolbanken.unikum.net/skolbanken/planering/3302884654

    var imageSRCs = [
        "../../css/src/vikingPuzzel/1.png",
        "../../css/src/vikingPuzzel/2.png",
        "../../css/src/vikingPuzzel/3.png",
        "../../css/src/vikingPuzzel/4.png",
        "../../css/src/vikingPuzzel/5.png",
        "../../css/src/vikingPuzzel/6.png",
        "../../css/src/vikingPuzzel/7.png",
        "../../css/src/vikingPuzzel/8.png",
        "../../css/src/vikingPuzzel/9.png"
    ];
    
    var canvasCTX   = $("#pusselCanvas")[0].getContext('2d');
    
    canvasCTX.canvas.width  = window.innerWidth;
    canvasCTX.canvas.height = window.innerHeight-100;

    var correctAnswers = parseInt(localStorage.getItem("vikingBitar"));

    console.log(correctAnswers);

    imageSRCs.forEach(src =>{
        if(imageSRCs.indexOf(src) < correctAnswers){
            const image = new Image();
            image.src = src;
            image.onload = () => {
                
                canvasCTX.drawImage(image, window.innerWidth/2 - image.width/1.3, window.innerHeight/2 - image.height/2, 750, 500);
            }
        }
    })

    var nollställ   = $("#reset");
    nollställ.click(function() {
        if(confirm("Är du säker på att du vill börja om med 0 pusselbitar för vikingatiden?")){
            localStorage.setItem("vikingBitar", 0);
            location.reload();
        }
    })

});