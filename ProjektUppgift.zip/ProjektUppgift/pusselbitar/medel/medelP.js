/*
    niot5439
    raah3489
    nama3213
*/

$(document).ready(function() {

    //Bild källa: https://www.worldhistory.org/image/11847/edward-iv-of-england--lancastrian-fugitives-at-tew/

    var imageSRCs = [
        "../../css/src/medelPuzzel/1.png",
        "../../css/src/medelPuzzel/2.png",
        "../../css/src/medelPuzzel/3.png",
        "../../css/src/medelPuzzel/4.png",
        "../../css/src/medelPuzzel/5.png",
        "../../css/src/medelPuzzel/6.png",
        "../../css/src/medelPuzzel/7.png",
        "../../css/src/medelPuzzel/8.png",
        "../../css/src/medelPuzzel/9.png"
    ];
    
    var canvasCTX   = $("#pusselCanvas")[0].getContext('2d');
    canvasCTX.canvas.width  = window.innerWidth;
    canvasCTX.canvas.height = window.innerHeight-100;

    var correctAnswers = parseInt(localStorage.getItem("medelBitar"));

    console.log(correctAnswers);

    imageSRCs.forEach(src =>{
        if(imageSRCs.indexOf(src) < correctAnswers){
            const image = new Image();
            image.src = src;
            image.onload = () => {
                
                canvasCTX.drawImage(image, window.innerWidth/2 - image.width/2.7, window.innerHeight/2 - image.height/3, 750, 500);
            }
        }
    })

    var nollställ   = $("#reset");
    nollställ.click(function() {
        if(confirm("Är du säker på att du vill börja om med 0 pusselbitar för medeltiden?")){
            localStorage.setItem("medelBitar", 0);
            location.reload();
        }
    })
});