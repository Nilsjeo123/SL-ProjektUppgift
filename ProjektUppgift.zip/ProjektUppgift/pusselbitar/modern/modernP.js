/*
    niot5439
    raah3489
    nama3213
*/

$(document).ready(function() {

    //Bild källa: https://www.10fakta.se/tag/amerikanska-frihetskriget/

    var imageSRCs = [
        "../../css/src/modernPuzzel/1.png",
        "../../css/src/modernPuzzel/2.png",
        "../../css/src/modernPuzzel/3.png",
        "../../css/src/modernPuzzel/4.png",
        "../../css/src/modernPuzzel/5.png",
        "../../css/src/modernPuzzel/6.png",
        "../../css/src/modernPuzzel/7.png",
        "../../css/src/modernPuzzel/8.png",
        "../../css/src/modernPuzzel/9.png"
    ];
    
    var canvasCTX   = $("#pusselCanvas")[0].getContext('2d');
    canvasCTX.canvas.width  = window.innerWidth;
    canvasCTX.canvas.height = window.innerHeight-100;

    var correctAnswers = parseInt(localStorage.getItem("modernBitar"));

    console.log(correctAnswers);

    imageSRCs.forEach(src =>{
        if(imageSRCs.indexOf(src) < correctAnswers){
            const image = new Image();
            image.src = src;
            image.onload = () => {
                
                canvasCTX.drawImage(image, window.innerWidth/2 - image.width/2.1, window.innerHeight/2 - image.height/2, 750, 500);
            }
        }
    })

    var nollställ   = $("#reset");
    nollställ.click(function() {
        if(confirm("Är du säker på att du vill börja om med 0 pusselbitar för den moderna eran?")){
            localStorage.setItem("modernBitar", 0);
            location.reload();
        }
    })
});