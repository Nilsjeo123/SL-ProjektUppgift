/*
    niot5439
    raah3489
    nama3213
*/

$(document).ready(function() {

    //Bild källa: https://varldenshistoria.se/teknik/maskiner/vavstolen-som-fick-varlden-att-ga-i-spinn
    
    var imageSRCs = [
        "../../css/src/indRevPuzzel/1.png",
        "../../css/src/indRevPuzzel/2.png",
        "../../css/src/indRevPuzzel/3.png",
        "../../css/src/indRevPuzzel/4.png",
        "../../css/src/indRevPuzzel/5.png",
        "../../css/src/indRevPuzzel/6.png",
        "../../css/src/indRevPuzzel/7.png",
        "../../css/src/indRevPuzzel/8.png",
        "../../css/src/indRevPuzzel/9.png"
    ];
    
    var canvasCTX   = $("#pusselCanvas")[0].getContext('2d');
    canvasCTX.canvas.width  = window.innerWidth;
    canvasCTX.canvas.height = window.innerHeight-100;

    var correctAnswers = parseInt(localStorage.getItem("indrevBitar"));

    console.log(correctAnswers);

    imageSRCs.forEach(src =>{
        if(imageSRCs.indexOf(src) < correctAnswers){
            const image = new Image();
            image.src = src;
            image.onload = () => {
                canvasCTX.drawImage(image, window.innerWidth/2 - image.width/4, window.innerHeight/2 - image.height/4, 750, 500);
            }
        }
    })

    var nollställ   = $("#reset");
    nollställ.click(function() {
        if(confirm("Är du säker på att du vill börja om med 0 pusselbitar för den industriella revolutionen?")){
            localStorage.setItem("indrevBitar", 0);
            location.reload();
        }
    })
});